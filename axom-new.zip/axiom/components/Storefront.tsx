'use client'
import { Canvas } from '@react-three/fiber'
import { useRef, useState } from 'react'
import ShardField from './ShardField'
import type { Offering, Shop, Sim } from '@/lib/types'

export default function Storefront({ shop, offerings }: { shop: Shop; offerings: Offering[] }) {
  const sim = useRef<Sim>({ shatter: false })
  const [sel, setSel] = useState<Offering | null>(null)
  const [sheet, setSheet] = useState<null | 'book'>(null)
  const [done, setDone] = useState(false)
  const [busy, setBusy] = useState(false)

  const shatterThen = (fn: () => void) => { sim.current.shatter = true; setTimeout(fn, 950) }
  const close = () => { setSheet(null); setDone(false); sim.current.shatter = false }

  const checkout = () => sel && shatterThen(() => {
    if (sel.checkout_url) window.location.href = sel.checkout_url
    else setSheet('book')
  })
  const book = () => sel && shatterThen(() => setSheet('book'))

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true)
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>
    const r = await fetch('/api/book', { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ shopId: shop.id, offeringId: sel?.id, ...f }) })
    setBusy(false); if (r.ok) setDone(true); else alert('Could not send your request. Please try again.')
  }

  return (
    <main className="stage" style={{ ['--brand' as string]: shop.brand_color ?? '#7fd6ff' }}>
      <Canvas camera={{ position: [0, 0, 10], fov: 40 }} dpr={[1, 1.75]} style={{ touchAction: 'none' }}
        gl={{ antialias: true }} onPointerMissed={() => {}}>
        <ShardField offerings={offerings} heroUrl={shop.hero_video_url || '/videos/hero.mp4'}
          selectedId={sel?.id ?? null} onSelect={setSel} sim={sim} />
      </Canvas>
      <header className="brand">{shop.name}</header>
      <nav className="dock">
        <p className="hint">{sel ? sel.title : 'Choose a service'}</p>
        <button disabled={!sel} onClick={book}>Book now</button>
        <button disabled={!sel} className="solid" onClick={checkout}>Instant checkout</button>
      </nav>
      {sheet && (
        <div className="sheet" role="dialog" aria-modal="true">
          <form onSubmit={submit}>
            {done ? (<><h2>Request sent</h2><p>{shop.name} will text you to confirm.</p><button type="button" className="solid" onClick={close}>Done</button></>) : (<>
              <h2>{sel?.title}</h2>
              <input name="customer_name" placeholder="Your name" required />
              <input name="customer_phone" placeholder="Mobile number" type="tel" required />
              <input name="requested_at" type="datetime-local" />
              <textarea name="notes" placeholder="Anything we should know?" rows={3} />
              <div className="row"><button type="button" onClick={close}>Back</button>
                <button className="solid" disabled={busy}>{busy ? 'Sending…' : 'Send booking request'}</button></div>
            </>)}
          </form>
        </div>)}
    </main>
  )
}
