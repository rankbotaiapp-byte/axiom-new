'use client'
import * as THREE from 'three'
import { Suspense, useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Environment, Text, useVideoTexture } from '@react-three/drei'
import { Dust } from '@/lib/dust'
import type { Offering, Sim } from '@/lib/types'

type Shard = {
  id: string; button: boolean; off?: Offering; ang: number; r: number; m: number
  pos: THREE.Vector3; vel: THREE.Vector3; rot: THREE.Vector3; spin: THREE.Vector3
  scale: number; phase: 'idle' | 'repel' | 'lock'; t: number; geo: number; grab: THREE.Vector3
}
const REPEL = 1.15, LOCK = 2.4, RELEASE = 3.0

/* ---------- Layer 1: hero video lives INSIDE the scene so the ice refracts it ---------- */
function HeroVideo({ url }: { url: string }) {
  const tex = useVideoTexture(url, { crossOrigin: 'anonymous', loop: true, muted: true })
  const { viewport, camera } = useThree()
  const z = -8, vp = viewport.getCurrentViewport(camera, [0, 0, z])
  const v = tex.image as HTMLVideoElement
  const va = (v?.videoWidth || 16) / (v?.videoHeight || 9)
  const w = vp.width / vp.height > va ? vp.width : vp.height * va
  return (
    <mesh position={[0, 0, z]} scale={[w, w / va, 1]}>
      <planeGeometry /><meshBasicMaterial map={tex} toneMapped={false} />
    </mesh>
  )
}

/* ---------- proof-of-work MP4 frame embedded inside a button shard ---------- */
function ClipFace({ url }: { url: string }) {
  const tex = useVideoTexture(url, { crossOrigin: 'anonymous', loop: true, muted: true })
  return (
    <mesh position={[0, 0.12, -0.12]}>
      <planeGeometry args={[1.5, 0.85]} /><meshBasicMaterial map={tex} toneMapped={false} />
    </mesh>
  )
}

export default function ShardField({
  offerings, heroUrl, selectedId, onSelect, sim,
}: { offerings: Offering[]; heroUrl: string; selectedId: string | null; onSelect: (o: Offering) => void; sim: React.RefObject<Sim> }) {
  const { camera, pointer } = useThree()
  const dust = useMemo(() => new Dust(), [])
  const refs = useRef<(THREE.Group | null)[]>([])
  const down = useRef(false), dragId = useRef<string | null>(null), wasShatter = useRef(false)
  const pw = useRef(new THREE.Vector3()), ppw = useRef(new THREE.Vector3())

  const geos = useMemo(() => {
    const btn = new THREE.CylinderGeometry(0.95, 1.05, 0.7, 6, 1).rotateX(Math.PI / 2)
    const shard = (s: number) => {
      const g = new THREE.IcosahedronGeometry(1, 0)
      const p = g.attributes.position
      for (let i = 0; i < p.count; i++) p.setXYZ(i, p.getX(i) * (0.6 + Math.sin(i * s) * 0.25), p.getY(i) * (1 + Math.cos(i * s) * 0.4), p.getZ(i) * 0.5)
      g.computeVertexNormals(); return g
    }
    return [btn, shard(1.7), shard(2.9), shard(4.1)]
  }, [])

  const shards = useMemo<Shard[]>(() => {
    const mk = (id: string, button: boolean, i: number, n: number, off?: Offering): Shard => ({
      id, button, off, ang: (i / Math.max(n, 1)) * Math.PI * 2 - Math.PI / 2, r: button ? 1.0 : 0.3 + Math.random() * 0.3,
      m: button ? 4 : 1, pos: new THREE.Vector3((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 4, 0.3),
      vel: new THREE.Vector3(), rot: new THREE.Vector3(Math.random() * 6, Math.random() * 6, Math.random() * 6),
      spin: new THREE.Vector3(), scale: 1, phase: 'idle', t: 0, geo: button ? 0 : 1 + (i % 3), grab: new THREE.Vector3(),
    })
    const b = offerings.map((o, i) => mk(o.id, true, i, offerings.length, o))
    b.forEach((s) => s.pos.set(0, -9, 0)) // fly in
    const d = Array.from({ length: 14 }, (_, i) => mk('d' + i, false, i, 14))
    return [...b, ...d]
  }, [offerings])

  useEffect(() => {
    const up = () => { down.current = false; dragId.current = null }
    const wheel = (e: WheelEvent) => {
      const s = shards.find((x) => x.id === dragId.current)
      if (s) { s.spin.z += e.deltaY * 0.02; s.spin.x += e.deltaX * 0.02 }
    }
    window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up)
    window.addEventListener('wheel', wheel, { passive: true })
    return () => { window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up); window.removeEventListener('wheel', wheel) }
  }, [shards])

  useFrame((state, dtRaw) => {
    const dt = Math.min(dtRaw, 1 / 30), time = state.clock.elapsedTime
    // pointer → world point on z=0 plane
    const v = new THREE.Vector3(pointer.x, pointer.y, 0.5).unproject(camera).sub(camera.position).normalize()
    const p = camera.position.clone().addScaledVector(v, -camera.position.z / v.z)
    const pv = p.clone().sub(pw.current).divideScalar(Math.max(dt, 1e-3)); pw.current.copy(p); ppw.current.copy(pv)
    const vpW = state.viewport.getCurrentViewport(camera, [0, 0, 0]).width
    const rx = Math.min(vpW * 0.36, 4.8), ry = rx * 0.4, cy = 0.55

    const shatter = !!sim.current?.shatter
    if (shatter && !wasShatter.current) {
      shards.forEach((s) => {
        const dir = s.pos.clone().sub(new THREE.Vector3(0, cy, 0)).add(new THREE.Vector3((Math.random() - .5), (Math.random() - .5), Math.random())).normalize()
        s.vel.addScaledVector(dir, 7 + Math.random() * 8); s.spin.set((Math.random() - .5) * 16, (Math.random() - .5) * 16, (Math.random() - .5) * 16)
        dust.emit(s.pos, 40, 5)
      })
    }
    if (!shatter && wasShatter.current) shards.forEach((s) => { s.vel.set(0, 0, 0); s.spin.set(0, 0, 0); s.scale = 0; s.phase = 'idle' })
    wasShatter.current = shatter

    for (const s of shards) {
      if (shatter) { // explosive free flight, then fade
        s.vel.multiplyScalar(1 - 0.8 * dt); s.pos.addScaledVector(s.vel, dt)
        s.scale = Math.max(0, s.scale - dt * 1.1)
      } else {
        s.scale = Math.min(1, s.scale + dt * 2.2)
        if (s.button) {
          const home = new THREE.Vector3(Math.cos(s.ang) * rx, Math.sin(s.ang) * ry + cy + Math.sin(time * 0.8 + s.ang * 3) * 0.06, 0.4)
          const cur = s.pos, toP = p.clone().sub(cur), dist = toP.length(), pd = p.distanceTo(home)
          if (s.phase === 'idle' && dist < REPEL && !down.current) { s.phase = 'repel'; s.t = 0; s.vel.addScaledVector(toP.clone().setZ(0).normalize(), -3.6) } // negative magnetic kick
          if (s.phase === 'repel') { s.t += dt; if (s.t > 0.32) s.phase = 'lock' }
          if (s.phase !== 'idle' && pd > RELEASE) s.phase = 'idle'
          let target = home, k = 18, c = 4.5
          if (s.phase === 'repel') { k = 6 }
          if (s.phase === 'lock' && pd < LOCK) { // slide back and relock onto cursor — low damping = ice
            target = home.clone().lerp(p.clone().setZ(0.4), 0.55); k = 14; c = 1.6
          }
          s.vel.addScaledVector(target.sub(cur), k * dt).multiplyScalar(Math.max(0, 1 - c * dt))
          s.pos.addScaledVector(s.vel, dt)
          // tilt toward motion, settle flat
          s.rot.x += ((-s.vel.y * 0.15) - s.rot.x) * Math.min(1, 8 * dt) + s.spin.x * dt
          s.rot.y += ((s.vel.x * 0.15) - s.rot.y) * Math.min(1, 8 * dt) + s.spin.y * dt
          s.rot.z += (0 - s.rot.z) * Math.min(1, 6 * dt)
        } else {
          if (dragId.current === s.id && down.current) { // drag, push, rotate
            const tgt = p.clone().add(s.grab); s.vel.copy(tgt.sub(s.pos).multiplyScalar(18)).clampLength(0, 22)
            s.spin.y += ppw.current.x * dt * 0.8; s.spin.x -= ppw.current.y * dt * 0.8
          } else {
            const pd = s.pos.distanceTo(p); // gentle cursor push
            if (pd < 0.9 && !down.current) s.vel.addScaledVector(s.pos.clone().sub(p).setZ(0).normalize(), 18 * dt)
          }
          s.vel.multiplyScalar(1 - 0.9 * dt); s.spin.multiplyScalar(1 - 0.7 * dt)
          s.pos.addScaledVector(s.vel, dt)
          s.pos.z += (0.3 - s.pos.z) * 4 * dt
          s.rot.addScaledVector(s.spin, dt)
          const hx = vpW / 2 - 0.3, hy = 3.3 // soft walls
          if (Math.abs(s.pos.x) > hx) { s.pos.x = Math.sign(s.pos.x) * hx; s.vel.x *= -0.6 }
          if (Math.abs(s.pos.y) > hy) { s.pos.y = Math.sign(s.pos.y) * hy; s.vel.y *= -0.6 }
        }
      }
    }
    // collisions → ice dust
    if (!shatter) for (let i = 0; i < shards.length; i++) for (let j = i + 1; j < shards.length; j++) {
      const a = shards[i], b = shards[j]; if (a.scale < 0.5 || b.scale < 0.5) continue
      const d = b.pos.clone().sub(a.pos); d.z = 0; const dist = d.length(), min = a.r + b.r
      if (dist >= min || dist < 1e-4) continue
      const n = d.divideScalar(dist), overlap = min - dist, tm = a.m + b.m
      a.pos.addScaledVector(n, -overlap * (b.m / tm)); b.pos.addScaledVector(n, overlap * (a.m / tm))
      const rel = b.vel.clone().sub(a.vel).dot(n)
      if (rel < 0) {
        const imp = (-(1 + 0.75) * rel) / (1 / a.m + 1 / b.m)
        a.vel.addScaledVector(n, -imp / a.m); b.vel.addScaledVector(n, imp / b.m)
        a.spin.z += (Math.random() - .5) * 4; b.spin.z += (Math.random() - .5) * 4
        if (-rel > 0.5) dust.emit(a.pos.clone().addScaledVector(n, a.r), Math.min(36, Math.floor(-rel * 7)), 1.5 + -rel * 0.4)
      }
    }
    shards.forEach((s, i) => {
      const g = refs.current[i]; if (!g) return
      g.position.copy(s.pos); g.rotation.set(s.rot.x, s.rot.y, s.rot.z); g.scale.setScalar(Math.max(s.scale, 0.0001))
    })
    dust.update(dt)
  })

  return (
    <>
      <Environment preset="city" />
      <ambientLight intensity={0.4} /><directionalLight position={[3, 5, 6]} intensity={1.4} />
      <Suspense fallback={null}><HeroVideo url={heroUrl} /></Suspense>
      {shards.map((s, i) => {
        const o = s.off, sel = o?.id === selectedId
        return (
          <group key={s.id} ref={(el) => { refs.current[i] = el }}
            onPointerDown={!s.button ? (e) => { e.stopPropagation(); down.current = true; dragId.current = s.id; s.grab.copy(s.pos).sub(pw.current).setZ(0) } : undefined}>
            <mesh geometry={geos[s.geo]} scale={s.button ? 1 : s.r * 1.6}
              onClick={s.button ? (e) => { e.stopPropagation(); onSelect(o!) } : undefined}
              onPointerOver={() => (document.body.style.cursor = s.button ? 'pointer' : 'grab')}
              onPointerOut={() => (document.body.style.cursor = '')}>
              <meshPhysicalMaterial transmission={1} thickness={s.button ? 0.9 : 0.6} roughness={o?.shard_roughness ?? 0.05}
                ior={o?.shard_ior ?? 1.31} color={o?.shard_color ?? '#bfe9ff'} attenuationColor="#9fdcff" attenuationDistance={2.5}
                clearcoat={1} envMapIntensity={1.4} emissive={sel ? '#5ecbff' : '#000'} emissiveIntensity={sel ? 0.35 : 0} />
            </mesh>
            {s.button && o?.clip_url && <Suspense fallback={null}><ClipFace url={o.clip_url} /></Suspense>}
            {s.button && o && (
              <Text position={[0, o.clip_url ? -0.48 : 0.08, 0.42]} fontSize={0.19} maxWidth={1.6} textAlign="center" anchorX="center" anchorY="middle"
                outlineWidth={0.012} outlineColor="#06121c" color="#ffffff">
                {o.title}{o.price_cents ? `\n$${(o.price_cents / 100).toFixed(0)}` : ''}
              </Text>
            )}
          </group>
        )
      })}
      <primitive object={dust.points} />
    </>
  )
}
