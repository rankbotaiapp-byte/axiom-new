'use client'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { browserClient } from '@/lib/supabase'
import type { Offering, Shop } from '@/lib/types'

type Asset = { id: string; offering_id: string | null; status: string; enhanced_url: string | null; clip_url: string | null; error: string | null }
const LOOPS = [['Snow leopard', '/videos/hero.mp4'], ['Custom (paste URL below)', '']]

export default function AdminStudio({ slug }: { slug: string }) {
  const db = useMemo(() => browserClient(), [])
  const [session, setSession] = useState<any>(null)
  const [email, setEmail] = useState(''); const [sent, setSent] = useState(false)
  const [shop, setShop] = useState<(Shop & { owner_id?: string }) | null>(null)
  const [offs, setOffs] = useState<Offering[]>([]); const [assets, setAssets] = useState<Asset[]>([])
  const [priv, setPriv] = useState({ twilio_to: '', sms_enabled: false })
  const [tab, setTab] = useState<'studio' | 'shards' | 'shop'>('studio')
  const [msg, setMsg] = useState(''); const [target, setTarget] = useState(''); const [prompt, setPrompt] = useState('')

  useEffect(() => { db.auth.getSession().then(({ data }) => setSession(data.session))
    const { data } = db.auth.onAuthStateChange((_e, s) => setSession(s)); return () => data.subscription.unsubscribe() }, [db])

  const load = useCallback(async () => {
    const { data: s } = await db.from('shops').select('*').eq('slug', slug).single(); if (!s) return setMsg('No shop found for this account.')
    setShop(s)
    const [o, a, p] = await Promise.all([db.from('offerings').select('*').eq('shop_id', s.id).order('sort'),
      db.from('assets').select('*').eq('shop_id', s.id).order('created_at', { ascending: false }).limit(10),
      db.from('shop_private').select('*').eq('shop_id', s.id).maybeSingle()])
    setOffs(o.data ?? []); setAssets(a.data ?? []); if (p.data) setPriv({ twilio_to: p.data.twilio_to ?? '', sms_enabled: p.data.sms_enabled })
  }, [db, slug])
  useEffect(() => { if (session) load() }, [session, load])
  useEffect(() => { if (!assets.some((a) => a.status === 'rendering' || a.status === 'enhancing')) return
    const t = setInterval(load, 5000); return () => clearInterval(t) }, [assets, load])

  const upload = async (file: File, folder: string) => {
    const path = `${shop!.id}/${folder}/${Date.now()}-${file.name.replace(/[^\w.-]/g, '_')}`
    const { error } = await db.storage.from('assets').upload(path, file, { upsert: true }); if (error) throw error
    return path
  }
  const generate = async (file?: File | null) => {
    if (!shop || (!file && !prompt)) return setMsg('Upload a PNG or describe the asset.')
    setMsg('Enhancing and branding…')
    try {
      const sourcePath = file ? await upload(file, 'logos') : undefined
      const r = await fetch('/api/studio', { method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ shopId: shop.id, offeringId: target || null, prompt, sourcePath }) })
      const j = await r.json(); setMsg(r.ok ? 'Rendering your 3D loop. It attaches to the shard automatically.' : j.error); load()
    } catch (e: any) { setMsg(e.message) }
  }
  const saveOff = async (o: Offering) => { const { error } = await db.from('offerings').update({ title: o.title, price_cents: o.price_cents, shard_color: o.shard_color,
    shard_ior: o.shard_ior, shard_roughness: o.shard_roughness, clip_url: o.clip_url || null, checkout_url: o.checkout_url || null, description: o.description }).eq('id', o.id); setMsg(error ? error.message : 'Saved') }
  const patchOff = (id: string, p: Partial<Offering>) => setOffs((x) => x.map((o) => (o.id === id ? { ...o, ...p } : o)))
  const saveShop = async () => { if (!shop) return
    const a = await db.from('shops').update({ name: shop.name, hero_video_url: shop.hero_video_url || null, brand_color: shop.brand_color }).eq('id', shop.id)
    const b = await db.from('shop_private').upsert({ shop_id: shop.id, ...priv }); setMsg(a.error?.message ?? b.error?.message ?? 'Saved') }

  if (!session) return (
    <main className="admin"><h1>Studio sign in</h1>
      {sent ? <p>Check your email for the sign-in link.</p> : <>
        <input type="email" placeholder="Owner email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <button className="solid" onClick={async () => { await db.auth.signInWithOtp({ email, options: { emailRedirectTo: location.href } }); setSent(true) }}>Email me a link</button></>}
    </main>)
  if (!shop) return <main className="admin"><p>{msg || 'Loading…'}</p></main>

  return (
    <main className="admin">
      <h1>{shop.name} studio</h1>
      <div className="tabs">{(['studio', 'shards', 'shop'] as const).map((t) => <button key={t} className={tab === t ? 'solid' : ''} onClick={() => setTab(t)}>{t === 'shop' ? 'Hero and alerts' : t === 'shards' ? 'Shards' : 'Asset studio'}</button>)}</div>
      {msg && <p className="muted" role="status">{msg}</p>}

      {tab === 'studio' && <section className="card">
        <label>Attach the finished loop to
          <select value={target} onChange={(e) => setTarget(e.target.value)}><option value="">Library only</option>{offs.map((o) => <option key={o.id} value={o.id}>{o.title}</option>)}</select></label>
        <label>Upload a PNG logo<input type="file" accept="image/png" onChange={(e) => generate(e.target.files?.[0])} /></label>
        <label>Or describe a new asset<textarea rows={2} value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Gold bear paw emblem for a pet groomer" /></label>
        <button className="solid" onClick={() => generate(null)}>Generate from description</button>
        {assets.map((a) => <div key={a.id} className="muted">{a.status}{a.error ? `: ${a.error}` : ''}
          {a.clip_url && <video src={a.clip_url} muted loop autoPlay playsInline style={{ width: '100%', borderRadius: 10, marginTop: 6 }} />}</div>)}
      </section>}

      {tab === 'shards' && <>{offs.map((o) => <section className="card" key={o.id}>
        <label>Title<input value={o.title} onChange={(e) => patchOff(o.id, { title: e.target.value })} /></label>
        <label>Price (cents)<input type="number" value={o.price_cents ?? ''} onChange={(e) => patchOff(o.id, { price_cents: +e.target.value })} /></label>
        <label>Ice tint<input type="color" value={o.shard_color ?? '#bfe9ff'} onChange={(e) => patchOff(o.id, { shard_color: e.target.value })} /></label>
        <label>Refraction (ior {o.shard_ior ?? 1.31})<input type="range" min="1" max="2.3" step="0.01" value={o.shard_ior ?? 1.31} onChange={(e) => patchOff(o.id, { shard_ior: +e.target.value })} /></label>
        <label>Roughness ({o.shard_roughness ?? 0.05})<input type="range" min="0" max="0.5" step="0.01" value={o.shard_roughness ?? 0.05} onChange={(e) => patchOff(o.id, { shard_roughness: +e.target.value })} /></label>
        <label>Niche video loop<select value={LOOPS.some((l) => l[1] === o.clip_url) ? o.clip_url! : ''} onChange={(e) => patchOff(o.id, { clip_url: e.target.value })}>{LOOPS.map(([n, v]) => <option key={n} value={v}>{n}</option>)}</select></label>
        <label>Clip URL<input value={o.clip_url ?? ''} onChange={(e) => patchOff(o.id, { clip_url: e.target.value })} /></label>
        <label>Stripe payment link<input value={o.checkout_url ?? ''} onChange={(e) => patchOff(o.id, { checkout_url: e.target.value })} placeholder="https://buy.stripe.com/…" /></label>
        <button className="solid" onClick={() => saveOff(o)}>Save shard</button></section>)}
        <button onClick={async () => { await db.from('offerings').insert({ shop_id: shop.id, title: 'New service', sort: offs.length }); load() }}>Add a shard</button></>}

      {tab === 'shop' && <section className="card">
        <label>Business name<input value={shop.name} onChange={(e) => setShop({ ...shop, name: e.target.value })} /></label>
        <label>Brand color<input type="color" value={shop.brand_color ?? '#7fd6ff'} onChange={(e) => setShop({ ...shop, brand_color: e.target.value })} /></label>
        <label>Background hero loop (MP4 URL)<input value={shop.hero_video_url ?? ''} onChange={(e) => setShop({ ...shop, hero_video_url: e.target.value })} /></label>
        <label>Or upload a hero MP4<input type="file" accept="video/mp4" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return
          const p = await upload(f, 'hero'); setShop({ ...shop, hero_video_url: db.storage.from('assets').getPublicUrl(p).data.publicUrl }) }} /></label>
        <label>Booking alerts go to (mobile)<input type="tel" value={priv.twilio_to} onChange={(e) => setPriv({ ...priv, twilio_to: e.target.value })} placeholder="+15415550123" /></label>
        <label><span><input type="checkbox" style={{ width: 'auto' }} checked={priv.sms_enabled} onChange={(e) => setPriv({ ...priv, sms_enabled: e.target.checked })} /> Text me instantly on each booking</span></label>
        <button className="solid" onClick={saveShop}>Save</button></section>}
    </main>)
}
