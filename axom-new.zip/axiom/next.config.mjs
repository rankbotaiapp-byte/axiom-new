export default { transpilePackages: ['three'], images: { unoptimized: true } }
