# Axiom storefront
1. `npm i` · copy `.env.example` → `.env.local` and fill it in.
2. Run `supabase/schema.sql` in the Supabase SQL editor. Add a shop row (`owner_id` = your auth user id) and a few `offerings`.
3. `npm run dev` → `/<slug>` is the storefront, `/<slug>/admin` is the studio (magic-link login).
4. Hero loop ships at `public/videos/hero.mp4`. Uploaded loops go to the `assets` bucket.
5. Deploy to Vercel; set `NEXT_PUBLIC_APP_URL` so Replicate webhooks reach `/api/studio/webhook`.
Twilio: set the three TWILIO_* vars, then enable alerts in Admin → Hero and alerts.
