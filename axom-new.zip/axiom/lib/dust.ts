import * as THREE from 'three'
/** Ring-buffer ice-dust particle system. Call emit() on impact, update() every frame. */
export class Dust {
  points: THREE.Points
  private n: number; private head = 0
  private pos: Float32Array; private col: Float32Array; private vel: Float32Array; private life: Float32Array
  constructor(n = 900) {
    this.n = n
    this.pos = new Float32Array(n * 3).fill(9999); this.col = new Float32Array(n * 3)
    this.vel = new Float32Array(n * 3); this.life = new Float32Array(n)
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3))
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3))
    const m = new THREE.PointsMaterial({
      size: 0.07, vertexColors: true, transparent: true, depthWrite: false,
      blending: THREE.AdditiveBlending, sizeAttenuation: true,
    })
    this.points = new THREE.Points(g, m); this.points.frustumCulled = false
  }
  emit(p: THREE.Vector3, count: number, speed = 2) {
    for (let k = 0; k < count; k++) {
      const i = this.head; this.head = (this.head + 1) % this.n
      this.pos.set([p.x, p.y, p.z], i * 3)
      const a = Math.random() * Math.PI * 2, b = (Math.random() - 0.5) * Math.PI, s = speed * (0.3 + Math.random())
      this.vel.set([Math.cos(a) * Math.cos(b) * s, Math.sin(b) * s, Math.sin(a) * Math.cos(b) * s], i * 3)
      this.life[i] = 0.6 + Math.random() * 0.9
    }
  }
  update(dt: number) {
    for (let i = 0; i < this.n; i++) {
      const l = this.life[i]
      if (l <= 0) { this.col[i * 3] = this.col[i * 3 + 1] = this.col[i * 3 + 2] = 0; continue }
      this.life[i] = l - dt * 1.3
      for (let k = 0; k < 3; k++) { this.pos[i * 3 + k] += this.vel[i * 3 + k] * dt; this.vel[i * 3 + k] *= 0.97 }
      this.vel[i * 3 + 1] -= dt * 0.5
      const tw = 0.6 + 0.4 * Math.sin(l * 40 + i) // sparkle
      this.col[i * 3] = 0.7 * l * tw; this.col[i * 3 + 1] = 0.92 * l * tw; this.col[i * 3 + 2] = l * tw
    }
    this.points.geometry.attributes.position.needsUpdate = true
    this.points.geometry.attributes.color.needsUpdate = true
  }
}
