import sharp from 'sharp'
const REP = 'https://api.replicate.com/v1'
const H = () => ({ Authorization: `Bearer ${process.env.REPLICATE_API_TOKEN}`, 'content-type': 'application/json' })

/** Text → image (used when the owner describes an asset instead of uploading a logo). */
export async function generateImage(prompt: string): Promise<Buffer> {
  const r = await fetch(`${REP}/models/${process.env.REPLICATE_IMAGE_MODEL}/predictions`, {
    method: 'POST', headers: { ...H(), Prefer: 'wait' },
    body: JSON.stringify({ input: { prompt: `${prompt}, clean centered logo mark, studio lighting, transparent-friendly`, aspect_ratio: '1:1' } }) })
  const j = await r.json(); const url = [j.output].flat()[0]
  if (!url) throw new Error('image generation failed')
  return Buffer.from(await (await fetch(url)).arrayBuffer())
}

/** Enhance + brand: trim, fit, drop-shadow, brand-tinted glacier backdrop, 16:9 frame. */
export async function enhance(src: Buffer, brand: string): Promise<Buffer> {
  const W = 1280, H_ = 720
  const logo = await sharp(src).trim().resize({ width: 640, height: 520, fit: 'inside' }).png().toBuffer()
  const m = await sharp(logo).metadata()
  const shadow = await sharp(logo).ensureAlpha().tint('#000').blur(18).png().toBuffer()
  const bg = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H_}"><defs>
    <radialGradient id="g" cx="50%" cy="45%" r="75%"><stop offset="0" stop-color="${brand}" stop-opacity=".55"/><stop offset="1" stop-color="#050b12"/></radialGradient></defs>
    <rect width="100%" height="100%" fill="url(#g)"/></svg>`)
  const left = Math.round((W - (m.width ?? 0)) / 2), top = Math.round((H_ - (m.height ?? 0)) / 2)
  return sharp(bg).composite([{ input: shadow, left, top: top + 14 }, { input: logo, left, top }]).png().toBuffer()
}

/** Enhanced still → 3D-depth animated MP4 loop (image-to-video provider, async via webhook). */
export async function startVideo(imageUrl: string, assetId: string) {
  const hook = `${process.env.NEXT_PUBLIC_APP_URL}/api/studio/webhook?asset=${assetId}&s=${process.env.STUDIO_WEBHOOK_SECRET}`
  const r = await fetch(`${REP}/models/${process.env.REPLICATE_VIDEO_MODEL}/predictions`, {
    method: 'POST', headers: H(),
    body: JSON.stringify({ input: { image: imageUrl, prompt: 'slow 3D parallax depth, gentle camera orbit, icy light glints, seamless loop, logo stays sharp' },
      webhook: hook, webhook_events_filter: ['completed'] }) })
  const j = await r.json(); if (!j.id) throw new Error('video start failed')
  return j.id as string
}
