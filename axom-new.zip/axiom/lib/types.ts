export type Offering = {
  id: string; shop_id: string; title: string; description: string | null
  price_cents: number | null; clip_url: string | null; checkout_url: string | null
  shard_color: string | null; shard_ior: number | null; shard_roughness: number | null; sort: number
}
export type Shop = {
  id: string; slug: string; name: string; hero_video_url: string | null; brand_color: string | null
}
export type Sim = { shatter: boolean }
export const NICHE_LOOPS: Record<string, string> = {
  'Snow leopard (default)': '/videos/hero.mp4',
  'Add your own: /videos/loops/<niche>.mp4': '',
}
