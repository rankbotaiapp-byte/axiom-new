export default function Home() { return <main style={{padding:40}}><h1>Axiom</h1><p>Visit /your-shop-slug</p></main> }
