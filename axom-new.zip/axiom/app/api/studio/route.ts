import { NextResponse } from 'next/server'
import { adminClient } from '@/lib/supabase'
import { enhance, generateImage, startVideo } from '@/lib/studio'
export const runtime = 'nodejs'; export const maxDuration = 60

export async function POST(req: Request) {
  const db = adminClient()
  const token = req.headers.get('authorization')?.replace('Bearer ', '')
  const { data: u } = await db.auth.getUser(token)
  if (!u.user) return NextResponse.json({ error: 'auth' }, { status: 401 })
  const { shopId, offeringId, prompt, sourcePath } = await req.json()
  const { data: shop } = await db.from('shops').select('id,brand_color').eq('id', shopId).eq('owner_id', u.user.id).single()
  if (!shop) return NextResponse.json({ error: 'forbidden' }, { status: 403 })
  if (offeringId) { const { data: o } = await db.from('offerings').select('id').eq('id', offeringId).eq('shop_id', shopId).single()
    if (!o) return NextResponse.json({ error: 'bad offering' }, { status: 400 }) }

  const { data: asset } = await db.from('assets').insert({ shop_id: shopId, offering_id: offeringId ?? null, prompt, status: 'enhancing' }).select().single()
  try {
    let src: Buffer
    if (sourcePath) { // only files inside this shop's own storage folder
      if (!String(sourcePath).startsWith(`${shopId}/`)) throw new Error('bad path')
      const { data, error } = await db.storage.from('assets').download(sourcePath); if (error) throw error
      src = Buffer.from(await data.arrayBuffer())
    } else if (prompt) src = await generateImage(prompt)
    else throw new Error('Upload a PNG or describe the asset')

    const out = await enhance(src, shop.brand_color ?? '#7fd6ff')
    const path = `${shopId}/studio/${asset!.id}.png`
    await db.storage.from('assets').upload(path, out, { contentType: 'image/png', upsert: true })
    const enhanced = db.storage.from('assets').getPublicUrl(path).data.publicUrl
    const pid = await startVideo(enhanced, asset!.id)
    await db.from('assets').update({ enhanced_url: enhanced, prediction_id: pid, status: 'rendering' }).eq('id', asset!.id)
    return NextResponse.json({ assetId: asset!.id })
  } catch (e: any) {
    await db.from('assets').update({ status: 'failed', error: String(e?.message ?? e) }).eq('id', asset!.id)
    return NextResponse.json({ error: String(e?.message ?? e) }, { status: 500 })
  }
}
