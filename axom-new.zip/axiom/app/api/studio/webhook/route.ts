import { NextResponse } from 'next/server'
import { adminClient } from '@/lib/supabase'
export const runtime = 'nodejs'; export const maxDuration = 60

export async function POST(req: Request) {
  const q = new URL(req.url).searchParams
  if (q.get('s') !== process.env.STUDIO_WEBHOOK_SECRET) return NextResponse.json({}, { status: 401 })
  const id = q.get('asset')!, db = adminClient(), j = await req.json()
  const { data: a } = await db.from('assets').select('*').eq('id', id).single()
  if (!a || a.prediction_id !== j.id) return NextResponse.json({}, { status: 404 })
  const url = [j.output].flat()[0]
  if (j.status !== 'succeeded' || !url) { await db.from('assets').update({ status: 'failed', error: String(j.error ?? 'no output') }).eq('id', id); return NextResponse.json({ ok: true }) }
  const buf = Buffer.from(await (await fetch(url)).arrayBuffer())
  const path = `${a.shop_id}/studio/${id}.mp4`
  await db.storage.from('assets').upload(path, buf, { contentType: 'video/mp4', upsert: true })
  const clip = db.storage.from('assets').getPublicUrl(path).data.publicUrl
  await db.from('assets').update({ clip_url: clip, status: 'ready' }).eq('id', id)
  if (a.offering_id) await db.from('offerings').update({ clip_url: clip }).eq('id', a.offering_id) // map to the shard
  return NextResponse.json({ ok: true })
}
