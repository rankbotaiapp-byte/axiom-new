import { NextResponse } from 'next/server'
import { adminClient } from '@/lib/supabase'
export const runtime = 'nodejs'
const clean = (v: unknown, max = 300) => String(v ?? '').trim().slice(0, max)

export async function POST(req: Request) {
  const b = await req.json().catch(() => null)
  const name = clean(b?.customer_name, 80), phone = clean(b?.customer_phone, 30)
  if (!b?.shopId || !name || !/^[+\d][\d\s().-]{6,}$/.test(phone)) return NextResponse.json({ error: 'invalid' }, { status: 400 })
  const db = adminClient()
  const { data: off } = b.offeringId
    ? await db.from('offerings').select('id,title').eq('id', b.offeringId).eq('shop_id', b.shopId).single() : { data: null }
  const requested = b.requested_at ? new Date(b.requested_at) : null
  const { error } = await db.from('bookings').insert({
    shop_id: b.shopId, offering_id: off?.id ?? null, customer_name: name, customer_phone: phone,
    requested_at: requested && !isNaN(+requested) ? requested.toISOString() : null, notes: clean(b.notes, 500) })
  if (error) return NextResponse.json({ error: 'db' }, { status: 500 })

  const { data: priv } = await db.from('shop_private').select('twilio_to,sms_enabled').eq('shop_id', b.shopId).single()
  const sid = process.env.TWILIO_ACCOUNT_SID, tok = process.env.TWILIO_AUTH_TOKEN
  if (priv?.sms_enabled && priv.twilio_to && sid && tok) {
    const body = `New booking: ${off?.title ?? 'Service'}\n${name} ${phone}\n${requested ? requested.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }) : 'No time chosen'}`
    await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: 'POST',
      headers: { Authorization: 'Basic ' + Buffer.from(`${sid}:${tok}`).toString('base64'), 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ To: priv.twilio_to, From: process.env.TWILIO_FROM!, Body: body }),
    }).catch(() => {}) // never fail the customer's booking because SMS failed
  }
  return NextResponse.json({ ok: true })
}
