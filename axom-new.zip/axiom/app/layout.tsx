import './globals.css'
export const metadata = { title: 'Axiom', description: 'Book in a few taps.' }
export const viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' as const }
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>
}
