import AdminStudio from '@/components/AdminStudio'
export default async function Admin({ params }: { params: Promise<{ shop: string }> }) {
  return <AdminStudio slug={(await params).shop} />
}
