import { notFound } from 'next/navigation'
import { publicClient } from '@/lib/supabase'
import Storefront from '@/components/Storefront'
export const revalidate = 30
export async function generateMetadata({ params }: { params: Promise<{ shop: string }> }) {
  const { shop } = await params
  const { data } = await publicClient().from('shops').select('name').eq('slug', shop).single()
  return { title: data?.name ?? 'Axiom' }
}
export default async function ShopPage({ params }: { params: Promise<{ shop: string }> }) {
  const { shop: slug } = await params
  const db = publicClient()
  const { data: shop } = await db.from('shops').select('id,slug,name,hero_video_url,brand_color').eq('slug', slug).single()
  if (!shop) notFound()
  const { data: offerings } = await db.from('offerings').select('*').eq('shop_id', shop.id).order('sort')
  return <Storefront shop={shop} offerings={offerings ?? []} />
}
