create extension if not exists pgcrypto;
create table shops (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  owner_id uuid not null references auth.users(id),
  hero_video_url text,
  brand_color text default '#7fd6ff',
  created_at timestamptz default now()
);
create table shop_private (            -- never publicly readable
  shop_id uuid primary key references shops(id) on delete cascade,
  twilio_to text, sms_enabled boolean default false
);
create table offerings (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references shops(id) on delete cascade,
  title text not null, description text, price_cents int,
  clip_url text, checkout_url text,
  shard_color text default '#bfe9ff',
  shard_ior numeric default 1.31, shard_roughness numeric default 0.05,
  sort int default 0
);
create table bookings (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references shops(id) on delete cascade,
  offering_id uuid references offerings(id) on delete set null,
  customer_name text not null, customer_phone text not null,
  requested_at timestamptz, notes text, created_at timestamptz default now()
);
create table assets (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references shops(id) on delete cascade,
  offering_id uuid references offerings(id) on delete set null,
  prompt text, source_url text, enhanced_url text, clip_url text,
  status text default 'queued', prediction_id text, error text,
  created_at timestamptz default now()
);
alter table shops enable row level security;
alter table shop_private enable row level security;
alter table offerings enable row level security;
alter table bookings enable row level security;
alter table assets enable row level security;

create policy "public read shops" on shops for select using (true);
create policy "owner write shops" on shops for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "public read offerings" on offerings for select using (true);
create policy "owner write offerings" on offerings for all
  using (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()))
  with check (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy "owner private" on shop_private for all
  using (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()))
  with check (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy "owner read bookings" on bookings for select
  using (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy "owner read assets" on assets for select
  using (exists (select 1 from shops s where s.id = shop_id and s.owner_id = auth.uid()));
-- bookings/assets are written only by server routes using the service role.

insert into storage.buckets (id, name, public) values ('assets','assets',true) on conflict do nothing;
create policy "public read assets bucket" on storage.objects for select using (bucket_id = 'assets');
create policy "owner upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'assets' and exists (
    select 1 from shops s where s.owner_id = auth.uid() and (storage.foldername(name))[1] = s.id::text));
